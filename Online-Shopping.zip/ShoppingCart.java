//Erin Owens copyright 2024
import java.util.ArrayList;

/**
 * The ShoppingCart class is a purely static class with both static methods and
 * attributes. The class needs to store a collection of Products and corresponding
 * counts. I would recommend using two ArrayLists, one ArrayList<Product> and one
 * ArrayList<Integer>. Note that you can treat Integers and ints as nearly identical, e.g.
 * int i = new Integer(0);
 * Integer j = 0;
 */
public class ShoppingCart {
	
	//helper class
	public static int findProduct(Product productInstance) {
//use a for loop to search through the productList arraylist. 
		for(int i = 0; i < productList.size(); i++) {
			if(productList.get(i).equals(productInstance)) {
				return i;
			}
		}
//if at any time the product in position i is the same product as productInstance, return that index (i). if not, return -1
		return -1;
	}
	/**
	 * The reset method initializes or clears any lists maintained and sets or
	 * resets any shipping or taxes. Assume this is always called once before building
	 * a new Order by adding/removing/deleting product instances.
	 * 
	 * @param shipping Value assigned as a shipping fees; must be >= 0.0
	 * @param federalTax Value assigned as any federal taxes; must be >= 0.0
	 * @param stateTax Value assigned as any state taxes; must be >= 0.0
	 */
	public static void reset(double shipping, double federalTax, double stateTax) {
//use the .clear() method to reset both array lists. also, assign parameters to static doubles	
		SHIPPING = shipping;
		if(SHIPPING < 0) {
			SHIPPING = 0.00;
		}
		FEDERAL_TAX = federalTax;
		if(FEDERAL_TAX < 0) {
			FEDERAL_TAX = 0.00;
		}
		STATE_TAX = stateTax;
		if(STATE_TAX < 0) {
			STATE_TAX = 0.00;
		}
			
		productList.clear(); 
		countList.clear();
	}
	
	/**
	 * Method addProduct accepts a Product instance.
	 * 
	 * If the added Product instance does not yet exist in the shopping cart, method makes a copy of the
	 * instance and sets count to 1.
	 * 
	 * If the added Product instance exists, method increases count by 1.
	 * 
	 * @param product
	 */
	public static void addProduct(Product productInstance) {
		int index = findProduct(productInstance);
		if(index == -1) { //means this product does not yet appear at all in the product list
			productList.add(productInstance);
			countList.add(1);
		}
		else {
			int updateCount = countList.get(index);
			countList.set(index, updateCount + 1);
		}
//define an int for index that is the result of the findProduct class (will be i or -1)
//if index results in -1, use the .add method of arraylist to add the product to productList and add 1 to countList
//if index results in the actual index of that product, just add 1 to the countlist
		//do this by first creating an int variable, maybe updateCount and set it equal to countList at the index (use .get)
		//then do this (from the directions): countList.set(index, currentCount + 1);
	}
	
	/**
	 * The buildOrder method creates an order from the present state of the
	 * ShoppingCart's lists.
	 * 
	 * This method creates a new Order instance, populates its attributes using
	 * the stored shipping and tax information, and adds all Products currently
	 * represented by the ShoppingCart's storage.
	 * 
	 * @return A complete Order instance, ready to be completed, presumably on
	 *         customer input.
	 */
	public static Order buildOrder() {
		Order orderInstance = new Order(); 
		orderInstance.setShipping(SHIPPING);
		orderInstance.setFederalTax(FEDERAL_TAX);		
		orderInstance.setStateTax(STATE_TAX);
		
		for(int i = 0; i < productList.size(); i++) {
			Product newProduct = productList.get(i);
			int newCount = countList.get(i);
			orderInstance.addProduct(newProduct, newCount); 
		}
		//use .set___Tax(static double) for all three taxes/expenses
		//inside a for-loop:
		//define two ints, newProduct and newCount that are equal to each arraylist using .get(i)
		//call to .addProduct method on orderInstance and pass the two new ints as params		
		return orderInstance;
	}
	
	/**
	 * The getContents method is essentially a toString method for a static class
	 * 
	 * Build the string by creating a list of product ids and counts as follows:
	 * 
	 * <<product id>> : <<product count>>
	 * 
	 * In this string, product id is, again, a 10 digit number, left-padded with
	 * 0s if less than 10 digits. Product count is a 4 digit number without padding. The
	 * two values are separated by " : ". 
	 * 
	 * @return The string described above.
	 */
	public static String getContents() {
		StringBuilder cartContent = new StringBuilder();
		for(int i = 0; i < productList.size(); i++) {
			cartContent.append(String.format("%010d", productList.get(i).id()))
			.append(" : ").append(String.format("%4d", countList.get(i))).append("\n");		
		}
		
		return cartContent.toString();
	}
	
	/**
	 * The removeProduct method decrements the count of, or removes the
	 * Product parameter.
	 * 
	 * If the Product instance does not exist in the list, the method
	 * does nothing.
	 * 
	 * If the Product instance exists in the list and count is greater than
	 * 1, decrements count.
	 * 
	 * If the Product instance exists in the list and count is 1, removes
	 * the instance and count from lists.
	 * 
	 * @param product
	 */
	public static void removeProduct(Product productInstance) {
		int index = findProduct(productInstance);
		int updateCount = countList.get(index);
		if(index != -1) { //means this product does not yet appear at all in the product list		
			countList.set(index, updateCount - 1);
		}
		if(updateCount == 1){//if the count that corresponds to this index is 1, delete the entire product and all its quantities
			productList.remove(index);
			countList.remove(index);
		}
	}
	
	/**
	 * The deleteProduct method removes all instances of the product
	 * parameter.
	 * 
	 * If the product parameter is found in the list, it and its count
	 * are removed.
	 * 
	 * @param product
	 */
	public static void deleteProduct(Product productInstance) {
		int index = findProduct(productInstance);
		productList.remove(index);
		countList.remove(index);		
	}
private static ArrayList<Product> productList = new ArrayList<>();
private static ArrayList<Integer> countList = new ArrayList<>();
private static double STATE_TAX;
private static double FEDERAL_TAX;
private static double SHIPPING;
}
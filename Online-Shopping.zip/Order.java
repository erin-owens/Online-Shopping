//Erin Owens copyright 2024

import java.util.ArrayList;

/**
 * Order class stores information about Products and how many are included in an
 * Order instance.
 */
class Order{

	/**
	 * Default Order constructor
	 * 
	 * Initializes any arrays or ArrayLists required, as well as tax and shipping
	 * info. The ShoppingCart class is expected to build instances of Order, so there
	 * is no need to provide further constructors.
	 */
	public Order() {
		stateTax = 0.00;
		federalTax = 0.00;
		shipping = 0.00;
		ArrayList <Product> productList = new ArrayList();
		this.productList = productList;
		ArrayList <Integer> countList = new ArrayList();
		this.countList = countList;
	}
	/**
	 * The addProduct method is called once per Product instance. Expected to
	 * be used by ShoppingCart, it will not be called until the final Order
	 * instance is ready to be returned.
	 * 
	 * You do not need to check for previously existing instances of the Product.
	 * Assume ShoppingCart will ensure this is used correctly.
	 * 
	 * @param product Description of product(s) added to Order instance
	 * @param count  Number of products represented in instance.
	 */
	public void addProduct(Product productInstance, int count) {
		productList.add(productInstance);
		countList.add(count);
	}
	
	/**
	 * Mutator for state tax.
	 * 
	 * @param stateTax Must be greater than 0.
	 */
	
	public void setStateTax(double stateTax) {
		if(stateTax <= 0) {
			stateTax = 0.00;
		}
		this.stateTax = stateTax;		
	}
	
	/**
	 * Mutator for federal tax.
	 * 
	 * @param federalTax Must be greater than 0.
	 */
	public void setFederalTax(double federalTax) {
		if(federalTax <= 0) {
			federalTax = 0.00;
		}
		this.federalTax = federalTax;
	}

	/**
	 * Mutator for shipping costs.
	 * 
	 * @param shipping Must be greater than 0.
	 */
	public void setShipping(double shipping) {
		if(shipping <= 0) {
			shipping = 0.00;
		}
		this.shipping = shipping;
	}
	
	/**
	 * The completeOrder method returns a final order with all calculations as a
	 * string. An example is:
	 *
	 Product List
		0001064960, "Phone Charger", $7.99	7
		0268435712, Marshmallows, $17.50	2
		0536879104, "Breath Mints", $1.25	1
	 Order Summary
		Product Total:	$92.18
		State Tax: 	$2.77
		Federal Tax:	$8.55
		Shipping:	$12.75
		Order Total:	$116.24
	 *
	 * Note, that is the string
	 * "Product List"
	 * Then, one per line,
	 *   A tab character "\t", A Product, A tab character "\t", Product Count
	 *   without commas. Followed by the string
	 *   "Order Summary"
	 * 
	 * A tab character "\t", The string "Product Total:", A tab character "\t",
	 *   The product total as a floating point rounded to two decimal places and
	 *   a dollar sign "$"
	 * 
	 * A tab character "\t", The string "Shipping:", A tab character "\t", The
	 *   shipping information as a floating point rounded to two decimal places and
	 *   a dollar sign "$"
	 *   
	 * If they exist,
	 *   A tab character "\t", The tax string, A tab character "\t", The shipping
	 *     information as a floating point rounded to two decimal places and a dollar
	 *     sign "$"
	 * 
	 * A tab character "\t", The string "Order Total:", A tab character "\t",
	 *   The order total as a floating point rounded to two decimal places and
	 *   a dollar sign "$"
	 *   
	 * @return The string described above.
	 */
	
	public String completeOrder(){
		StringBuilder finalOrder = new StringBuilder();
		finalOrder.append("Product List\n");
		//create and format the part of the string that prints the product ID, name, and quantity also find product total when quantity > 1 is bought
		double productTotal = 0.00;
		for(int i = 0; i < productList.size(); i++) {
			Product product = productList.get(i);
			int productCount = countList.get(i);
			productTotal += product.price() * productCount;
			finalOrder.append("\t").append(product.toString()).append("\t").append(productCount).append("\n");
		}
		//calculate and round tax values
		double stateTaxTotal = (stateTax * productTotal);
		String stateTaxValue = String.format("%.2f", stateTaxTotal);
		double federalTaxTotal = (federalTax * (productTotal + Double.parseDouble(stateTaxValue)));
		String federalTaxValue = String.format("%.2f", federalTaxTotal);
		
		String formatShipping = String.format("%.2f", shipping);
		
		//create the part of the string that deals w taxes and shipping
		String formatProductTotal = String.format("%.2f", productTotal);
		double orderTotal = stateTaxTotal + federalTaxTotal 
		+ shipping + productTotal;
		
		String formatOrderTotal = String.format("%.2f", orderTotal);
		
		//build finalOrder String
		finalOrder.append("Order Summary\n").append("\tProduct Total:\t$").append(formatProductTotal).append("\n");
		if(stateTax != 0) {
			finalOrder.append("\tState Tax: \t$").append(stateTaxValue).append("\n");
		}
		if(federalTax != 0) {
			finalOrder.append("\tFederal Tax:\t$").append(federalTaxValue).append("\n");
		}
		finalOrder.append("\tShipping:\t$").append(formatShipping).append("\n");
		finalOrder.append("\tOrder Total:\t$").append(formatOrderTotal);

		return finalOrder.toString();
	}
private ArrayList<Product> productList; 
private ArrayList<Integer> countList;
private double stateTax;
private double federalTax;
private double shipping;
}